#ifndef WemosAutoupdate_h
#define WemosAutoupdate_h

#include "Arduino.h"

class WemosAutoupdate {

  public:
    WemosAutoupdate(int interval, String host, String deviceId, bool autoRestart);
    void loop();
  private:
    int _interval;
    String _host;
    bool _autoRestart;
    long _lastUpdate;
    String _deviceId;
};

#endif
